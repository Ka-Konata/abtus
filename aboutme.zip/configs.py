from decouple import config

TOKEN = config("ABOUT_DISCORD_TOKEN")