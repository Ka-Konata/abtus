function redFriends() {
    window.location.href = "/k/friends"
}

function redYoutube() {
    window.location.href = "https://www.youtube.com/channel/UCw1Fgt52i6AYGVhHBHge_xg"
}

function redGithub() {
    window.location.href = "https://github.com/Ka-Konata"
}


function copyText() {
    var button = document.getElementById("copiar")
    button.value = "Copiado!"
    navigator.clipboard.writeText("Ka#0001")
}